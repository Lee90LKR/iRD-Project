# Backend
import os
import random
from pathlib import Path

import psycopg2 as pg
import psycopg2.extras as pg_extras
from dotenv import load_dotenv
import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from flask import Flask, render_template, request, redirect, url_for, session, flash
from werkzeug.security import generate_password_hash, check_password_hash

# Load environment variables from the project folder
BASE_DIR = Path(__file__).resolve().parent
load_dotenv(BASE_DIR / ".env")

# Basic test output (kept from your original code)
print("HELLO")
X = 8
Y = 2
print(X + Y)

class User:
    def get_roles(self):
        return ["admin", "editor"]

user = User()
if "admin" in user.get_roles():
    print("User admin")

# -----------------------------------------------------------------------------
# LOAD DATASET
# Put Epileptic Seizure Recognition.csv in the same folder as Main_App.py,
# or set DATASET_PATH in your .env file to its full path.
# -----------------------------------------------------------------------------
DATASET_PATH = os.getenv(
    "DATASET_PATH",
    str(BASE_DIR / "Epileptic Seizure Recognition.csv")
)

df = None
try:
    df = pd.read_csv(DATASET_PATH)
    df = df.loc[:, ~df.columns.astype(str).str.startswith("Unnamed")]
    print("Your data has loaded successfully! Shape:", df.shape)
except FileNotFoundError:
    print(f"Failed to load your dataset: file not found: {DATASET_PATH}")
except Exception as e:
    print(f"Failed to load your dataset: {e}")

# -----------------------------------------------------------------------------
# EEG SIMULATION
# -----------------------------------------------------------------------------
def get_simulated_data(sample_index=0):
    if df is None or df.empty or "y" not in df.columns:
        return {
            "sample_number": 1,
            "dataset_label": 0,
            "status": "Normal",
            "eeg_signal": 23.4,
            "motion_index": 0.15,
            "heart_rate": 72,
            "battery": 98,
            "timestamp": "Just now",
            "eeg_values": {},
            "eeg_chart_values": []
        }

    sample_index = int(sample_index) % len(df)
    sample = df.iloc[sample_index]
    feature_columns = [col for col in df.columns if col != "y"]
    eeg_values = pd.to_numeric(sample[feature_columns], errors="coerce")
    dataset_label = int(sample["y"])

    # LABELS
    status = "Seizure Alert Detected" if dataset_label == 1 else "Normal"

    return {
        "sample_number": sample_index + 1,
        "dataset_label": dataset_label,
        "status": status,
        "eeg_signal": round(float(eeg_values.iloc[0]), 2) if not eeg_values.empty else 23.4,
        "motion_index": round(float(np.random.uniform(0.05, 0.45)), 2),
        "heart_rate": random.randint(68, 120) if dataset_label == 1 else random.randint(65, 82),
        "battery": random.randint(80, 99),
        "timestamp": pd.Timestamp.now().strftime("%Y-%m-%d %H:%M:%S"),
        "eeg_values": eeg_values.head(10).to_dict(),
        "eeg_chart_values": eeg_values.tolist()
    }

# Creating app
app = Flask(__name__)
app.secret_key = os.getenv("FLASK_SECRET_KEY")