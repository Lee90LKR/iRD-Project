Python code for IT PROJECT: - Main_App.py

#FrontEnd
import os
import datetime
import psycopg2 as pg
from dotenv import load_dotenv
import altair as alt
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import requests
import plotly.express as px
from flask import Flask,render_template, request, redirect, url_for, session, flash

###TESTING CODE IS RNNING
print("HELLO")
x=8
y=2
sum = x+y
print(sum)
###TEST DONE

#Load datasets
load_dotenv()

#Creating apps
app = Flask(__name__)
app.secret_key = os.getenv("FLASK_KEY")

#EMERGENCY_NUM:
Emergency_num = {
   "Police": "10111",
   "Ambulance": "10177",
}

#Database
#Host: localhost
# User:
# Password:
# Database:
# URL: jdbc:postgresql://localhost:5432/IW_Patient_Data#

def get_db_connection():
    return pg.connect(
        host=os.getenv("host","localhost"),
        database=os.getenv("dbname"),
        database_user=os.getenv("db_user"),
        db_password=os.getenv("db_password"),

#Connection to web application
@app.route("/", methods=["GET", "POST"])
def welcome(): #WELCOMEPAGE
    return render_template("WelcomePage.html")

@app.route("/homepage")
def homepage():
    return render_template("HomePage.html")

@app.route("/signup", methods=["GET", "POST"])
def signup():
    if request.method == "POST":
        username = request.form["usrname"]
        name = request.form["name"]
        sname = request.form["sname"]
        email = request.form["email"]
        password = request.form["pwrd"]
        user_role = request.form["usrrole"]

        try:
            conn = get_db_connection()
            cur = conn.cursor()

            cur.execute(
                "INSERT INTO user (username, name, surname, email, password, usrrole) VALUES (%s, %s, %s, %s, %s)",
                (username, name, sname, email, password, user_role),
            )
            conn.commit()
            cur.close()
            conn.close()

            flash("Your registration was Successful! Please log into your account.")
            return redirect("LoginPage.html")
        except Exception as error_msg:
            print(f"Registration failed: {error_msg}")
            flash("Registration failed. Please try again.")
    return render_template("Sign_UpPage.html")

@app.route("/login". methods=["GET", "POST"])
def login():
    if request.method == "POST":
        username = request.form["usrname"]
        password = request.form["pwrd"]

        try:
            conn = get_db_connection()
            cur = conn.cursor()

            cur.execute("SELECT * FROM Users WHERE username = %s", (username,))
            record = cur.fetchone()
            cur.close()
            conn.close()

            if record and record[0] == password:
                session["username"] = username
                session["user_role"] = record[1]
                session['logged_in'] = True

                return redirect("HomePage.html")
            else:
                flash("Login Unsuccessful. Please check username and password.")
                return render_template("LoginPage.html")

        except Exception as error_msg:
            print(f"Authenticaton Error:{error_msg}")
            flash("Account Authenticaton failed. Please try again.")
    return render_template("LoginPage.html")

@app.route("/contact", methods=["GET", "POST"])
def contact():
    return render_template("CnctPage.html")
