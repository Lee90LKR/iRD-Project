SELECT user_id, name, surname, email
FROM users;

INSERT INTO user_roles (user_id, user_type, account_status)
VALUES
(1, 'Admin', 'Approved'),
(2, 'Medic', 'Pending'),
(3, 'Patient', 'Approved'),
(4, 'Family', 'Approved');

SELECT
    u.user_id,
    u.name,
    u.surname,
    u.email,
    ur.user_type,
    ur.account_status
FROM users u
JOIN user_roles ur ON u.user_id = ur.user_id
ORDER BY u.user_id;