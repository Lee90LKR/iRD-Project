UPDATE user_roles
SET account_status = 'Approved'
WHERE user_id = 2
AND user_type = 'Medic';

UPDATE user_roles
SET account_status = 'Rejected'
WHERE user_id = 2
AND user_type = 'Medic';